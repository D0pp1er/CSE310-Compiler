int a;
int b,c;
float dedffd;