flex -o wordcount.c 1905028.l
g++ wordcount.c -lfl -o wordcount.out
./wordcount.out input3.txt
